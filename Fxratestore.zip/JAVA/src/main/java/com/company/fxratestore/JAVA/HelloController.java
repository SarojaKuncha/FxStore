package com.company.fxratestore.JAVA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.*;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONObject;
import java.sql.DriverManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@RestController
@EnableAutoConfiguration
@RequestMapping("/")
public class HelloController {

	RestTemplate restTemplate = new RestTemplate();
	String URL_RATES_JSON = "https://api.exchangeratesapi.io/latest?base=";
	String URL_RATES_DATE = "https://api.exchangeratesapi.io/";
	String URL_CONSUME = "https://emjapisamplesjmsp2p.cfapps.eu10.hana.ondemand.com/queue/sfxratesq/message";

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = "text/plain")
	@ResponseBody
	String home() {
		StringBuilder builder = new StringBuilder();
		builder.append("Hello World !!");

		builder.append("\n\nJDBC connection available: ");
		try {
			Connection conn = getConnection();
			if (conn != null) {
				builder.append("yes");
				builder.append("\n\nCurrent Hana DB user:\n");
				String userName = getCurrentUser(conn);
				builder.append(userName);
				builder.append("\n\nCurrent Hana schema:\n");
				builder.append(getCurrentSchema(conn));
			} else {
				builder.append("no");
			}
		} catch (SQLException e) {
			builder.append("no");
		}

		return builder.toString();
	}

	private String getCurrentUser(Connection conn) throws SQLException {
		String currentUser = "";
		PreparedStatement prepareStatement = conn.prepareStatement("SELECT CURRENT_USER \"current_user\" FROM DUMMY;");
		ResultSet resultSet = prepareStatement.executeQuery();
		int column = resultSet.findColumn("current_user");
		while (resultSet.next()) {
			currentUser += resultSet.getString(column);
		}
		return currentUser;
	}

	private String getCurrentSchema(Connection conn) throws SQLException {
		String currentSchema = "";
		PreparedStatement prepareStatement = conn
				.prepareStatement("SELECT CURRENT_SCHEMA \"current_schema\" FROM DUMMY;");
		ResultSet resultSet = prepareStatement.executeQuery();
		int column = resultSet.findColumn("current_schema");
		while (resultSet.next()) {
			currentSchema += resultSet.getString(column);
		}
		return currentSchema;
	}

	private Connection getConnection() {
		Connection conn = null;
		String DB_USERNAME = "";
		String DB_PASSWORD = "";
		String DB_HOST = "";
		String DB_PORT = "";

		try {
			JSONObject obj = new JSONObject(System.getenv("VCAP_SERVICES"));
			JSONArray arr = obj.getJSONArray("hana");
			String s = arr.toString();
			System.out.println(s);
			DB_USERNAME = arr.getJSONObject(0).getJSONObject("credentials").getString("user");
			DB_PASSWORD = arr.getJSONObject(0).getJSONObject("credentials").getString("password");
			DB_HOST = arr.getJSONObject(0).getJSONObject("credentials").getString("host").split(",")[0];
			DB_PORT = arr.getJSONObject(0).getJSONObject("credentials").getString("port");
			// String DB_READ_CONNECTION_URL = "jdbc:sap://" + DB_HOST + ":" + DB_PORT;
			String DB_READ_CONNECTION_URL = "jdbc:sap://zeus.hana.prod.eu-central-1.whitney.dbaas.ondemand.com:21794?encrypt=true&validateCertificate=true&currentschema=FXRATESTORE_HDI_DB_1";

			conn = (Connection) DriverManager.getConnection(DB_READ_CONNECTION_URL, DB_USERNAME, DB_PASSWORD);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return conn;
	}

	@RequestMapping(value = "/fxrates/apirates/{baseCurrency}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Root getAPIRates(@PathVariable("baseCurrency") String baseCurrency) {
		RestTemplate restTemplate = new RestTemplate();
		Root result = restTemplate.getForObject(URL_RATES_JSON + baseCurrency, Root.class);
		System.out.println(URL_RATES_JSON + baseCurrency);
		try {
			Connection conn = getConnection();
			Rates rates = result.getRates();
			Map<String, Object> map = beanProperties(rates);
			Object obj = map.remove("tryc");
			// map.put("try", obj);
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				System.out.println("Key = " + entry.getKey().toUpperCase() + ", Value = " + entry.getValue());
				String query = "INSERT INTO " + getCurrentSchema(conn) + "."
						+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"" + "VALUES(?,?,?,?,?,?,?,?)";
				System.out.println(query);
				PreparedStatement preparedStatement = conn.prepareStatement(query);
				preparedStatement.setInt(1, 7);
				preparedStatement.setString(2, baseCurrency);
				preparedStatement.setString(3, entry.getKey().toUpperCase());
				preparedStatement.setString(4, null);
				preparedStatement.setDouble(5, (Double) entry.getValue());
				preparedStatement.setString(6, getDateString());
				preparedStatement.setString(7, "exchangeratesapi.io");
				preparedStatement.setString(8, getDateString());
				preparedStatement.executeUpdate();

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "/fxrates/fromQueue", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Root getAPIRatesfromQueue() {
		RestTemplate restTemplate = new RestTemplate();
		Root result = restTemplate.getForObject(URL_RATES_JSON, Root.class);
		System.out.println(URL_CONSUME);
		try {
			Connection conn = getConnection();
			Rates rates = result.getRates();
			Map<String, Object> map = beanProperties(rates);
			Object obj = map.remove("tryc");
			// map.put("try", obj);
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				System.out.println("Key = " + entry.getKey().toUpperCase() + ", Value = " + entry.getValue());
				String query = "INSERT INTO " + getCurrentSchema(conn) + "."
						+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"" + "VALUES(?,?,?,?,?,?,?,?)";
				System.out.println(query);
				PreparedStatement preparedStatement = conn.prepareStatement(query);
				preparedStatement.setInt(1, 7);
				preparedStatement.setString(2, "USD");
				preparedStatement.setString(3, entry.getKey().toUpperCase());
				preparedStatement.setString(4, null);
				preparedStatement.setDouble(5, (Double) entry.getValue());
				preparedStatement.setString(6, getDateString());
				preparedStatement.setString(7, "exchangeratesapi.io");
				preparedStatement.setString(8, getDateString());
				preparedStatement.executeUpdate();

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getMessage());
		}
		return result;
	}

	@GetMapping(value = "/fxrates/getRates/{baseCurrency}/{datePicker}", produces = "application/json")
	@ResponseBody
	private List<RatesTableEntity> getRates(@PathVariable("baseCurrency") String baseCurrency,
			@PathVariable("datePicker") String datePicker) {
		Connection conn = getConnection();
		List<RatesTableEntity> employess = new ArrayList<RatesTableEntity>();
		/*
		 * if (StringUtils.isEmpty(baseCurrency) && StringUtils.isEmpty(datePicker)) {
		 * baseCurrency = "USD"; datePicker = getDateString(); } else if
		 * (StringUtils.isEmpty(baseCurrency)) { baseCurrency = "USD"; } else if
		 * (StringUtils.isEmpty(datePicker)) { datePicker = getDateString(); }
		 */
		if (datePicker.equalsIgnoreCase("nodate")) {
			datePicker = getDateString();
		}
		StringBuilder builder1 = new StringBuilder();
		Statement stmt = null;
		boolean apiCall = false;
		System.out.println("Input Parameters : "+ baseCurrency+"/n"+datePicker);
		try {
			String verfyQuery = "SELECT  * from " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\" where \"base_currency\" = ? and \"lastUpdateTimeStamp\"=?";
			PreparedStatement preparedStatement1 = conn.prepareStatement(verfyQuery);
			System.out.println(verfyQuery);
			preparedStatement1.setString(1, baseCurrency);
			preparedStatement1.setString(2, datePicker);
			ResultSet resultSet = preparedStatement1.executeQuery();
			/*
			 * if (!resultSet.isBeforeFirst()) { apiCall = true; restApiCall(baseCurrency,
			 * datePicker); ResultSet resultSet1 = preparedStatement1.executeQuery(); while
			 * (resultSet1.next()) { RatesTableEntity emp = new RatesTableEntity();
			 * emp.setBaseCurrency(resultSet1.getString(2));
			 * emp.setToCurrency(resultSet1.getString(3));
			 * emp.setRate(resultSet1.getDouble(5));
			 * emp.setLastUpdateTimeStamp(resultSet1.getString(6));
			 * emp.setSource(resultSet1.getString(7));
			 * emp.setRequestedDateTime(resultSet1.getString(8)); employess.add(emp); } }
			 * else {
			 */
			while (resultSet.next()) {
				RatesTableEntity emp = new RatesTableEntity();
				emp.setBaseCurrency(resultSet.getString(2));
				emp.setToCurrency(resultSet.getString(3));
				emp.setRate(resultSet.getDouble(5));
				emp.setLastUpdateTimeStamp(resultSet.getString(6));
				emp.setSource(resultSet.getString(7));
				emp.setRequestedDateTime(resultSet.getString(8));
				employess.add(emp);
			}
			/* } */

			builder1.append("\n\nRecords Inserted:\n");
			System.out.println("Records Inserted");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			builder1.append(e.getMessage());
			System.out.println(e.getMessage());

		}
		return employess;
	}

	@GetMapping(value = "/fxrates/CompareRates", produces = "application/json")
	@ResponseBody
	private List<RatesTableEntity> getComapreRates() {
		Connection conn = getConnection();
		List<RatesTableEntity> employess = new ArrayList<RatesTableEntity>();
		/*
		 * if (StringUtils.isEmpty(baseCurrency) && StringUtils.isEmpty(datePicker)) {
		 * baseCurrency = "USD"; datePicker = getDateString(); } else if
		 * (StringUtils.isEmpty(baseCurrency)) { baseCurrency = "USD"; } else if
		 * (StringUtils.isEmpty(datePicker)) { datePicker = getDateString(); }
		 */
		Statement stmt = null;

		StringBuilder builder1 = new StringBuilder();
		try {
			String query = "SELECT * from " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.compare_source_rates\"";
			System.out.println(query);
			String verfyQuery = "SELECT  * from " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.compare_source_rates\" where \"base_currency\" = ? and \"lastUpdateTimeStamp\"=?";
			System.out.println(verfyQuery);
			stmt = conn.createStatement();
			ResultSet resultSet = stmt.executeQuery(query);

			while (resultSet.next()) {
				RatesTableEntity emp = new RatesTableEntity();
				emp.setBaseCurrency(resultSet.getString(2));
				emp.setToCurrency(resultSet.getString(3));
				emp.setRate(resultSet.getDouble(5));
				emp.setLastUpdateTimeStamp(resultSet.getString(6));
				emp.setSource(resultSet.getString(7));
				emp.setRequestedDateTime(resultSet.getString(8));
				employess.add(emp);
			}

			builder1.append("\n\nRecords Inserted:\n");
			System.out.println("Records Inserted");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			builder1.append(e.getMessage());
			System.out.println(e.getMessage());

		}
		return employess;
	}
    @RequestMapping(value = "/fxrates/addEntry", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
//	@PutMapping(path = "/fxrates/addEntry", consumes = "application/json")
	public @ResponseBody String addRate(@RequestBody RatesTableEntity emp) {
		StringBuilder builder1 = new StringBuilder();
		try {
			Connection conn = getConnection();
			String query = "INSERT INTO " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"" + "VALUES(?,?,?,?,?,?,?,?)";
			System.out.println(query);
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, 7);
			preparedStatement.setString(2, emp.getBaseCurrency());
			preparedStatement.setString(3, emp.getToCurrency());
			preparedStatement.setDouble(4, emp.getRate());
			preparedStatement.setString(5, null);
			preparedStatement.setString(6, getDateString());
			preparedStatement.setString(7, "manual");
			preparedStatement.setString(8, getDateString());
			preparedStatement.executeUpdate();
			builder1.append("\n\nRecords Inserted:\n");
			System.out.println("Records Inserted");
			return builder1.toString();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			builder1.append(e.getMessage());
			System.out.println(e.getMessage());
			return builder1.toString();
		}

	}

	public static Map<String, Object> beanProperties(Object bean) {
		try {
			Map<String, Object> map = new HashMap<>();
			Arrays.asList(Introspector.getBeanInfo(bean.getClass(), Object.class).getPropertyDescriptors()).stream()
					.filter(pd -> Objects.nonNull(pd.getReadMethod())).forEach(pd -> { // invoke method to get value
						try {
							Object value = pd.getReadMethod().invoke(bean);
							if (value != null) {
								map.put(pd.getName(), value);
							}
						} catch (Exception e) {
						}
					});
			return map;
		} catch (IntrospectionException e) {
			// and here, too
			return Collections.emptyMap();
		}
	}

	public String getDateString() {
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String strDate = dateFormat.format(date);
		System.out.println("Converted String: " + strDate);
		return strDate;
	}

	public String selectRates(String baseCurrency) {
		Connection conn = getConnection();
		List<RatesTableEntity> employess = new ArrayList<RatesTableEntity>();
		StringBuilder builder1 = new StringBuilder();
		Statement stmt = null;
		try {
			String query = "SELECT * from " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"";
			System.out.println(query);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				RatesTableEntity emp = new RatesTableEntity();
				emp.setBaseCurrency(rs.getString(2));
				emp.setToCurrency(rs.getString(3));
				emp.setRate(rs.getDouble(5));
				emp.setLastUpdateTimeStamp(rs.getString(6));
				emp.setSource(rs.getString(7));
				emp.setRequestedDateTime(rs.getString(8));
				employess.add(emp);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			builder1.append(e.getMessage());
			System.out.println(e.getMessage());
			return builder1.toString();

		}

		return null;
	}

	public String restApiCall(String baseCurrency, String datePicker) {
		RestTemplate restTemplate = new RestTemplate();
		String url = null;
		if (!datePicker.equals(getDateString())) {
			url = URL_RATES_DATE + datePicker + "?base=" + baseCurrency;
		}
		url = URL_RATES_JSON;
		Root result = restTemplate.getForObject(url + baseCurrency, Root.class);
		System.out.println(URL_RATES_JSON + baseCurrency);
		try {
			Connection conn = getConnection();
			Rates rates = result.getRates();
			Map<String, Object> map = beanProperties(rates);
			Object obj = map.remove("tryc");
			// map.put("try", obj);
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				System.out.println("Key = " + entry.getKey().toUpperCase() + ", Value = " + entry.getValue());
				String query = "INSERT INTO " + getCurrentSchema(conn) + "."
						+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"" + "VALUES(?,?,?,?,?,?,?,?)";
				System.out.println(query);
				PreparedStatement preparedStatement = conn.prepareStatement(query);
				preparedStatement.setInt(1, 7);
				preparedStatement.setString(2, baseCurrency);
				preparedStatement.setString(3, entry.getKey().toUpperCase());
				preparedStatement.setString(4, null);
				preparedStatement.setDouble(5, (Double) entry.getValue());
				preparedStatement.setString(6, datePicker);
				preparedStatement.setString(7, "exchangeratesapi.io");
				preparedStatement.setString(8, getDateString());
				preparedStatement.executeUpdate();

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getMessage());
		}
		return "Done";
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(HelloController.class, args);
	}

	@GetMapping(value = "/fxrates/getCodes", produces = "application/json")
	@ResponseBody
	private List<RatesTableEntity> getCodes() {
		List<RatesTableEntity> employess = new ArrayList<RatesTableEntity>();
		Connection conn = getConnection();
		StringBuilder builder1 = new StringBuilder();
		Statement stmt = null;
		try {
			String query = "SELECT * from " + getCurrentSchema(conn) + "."
					+ "\"Fxratestore.db::cdsArtifact.source_fx_rates\"";
			System.out.println(query);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				RatesTableEntity emp = new RatesTableEntity();
				emp.setBaseCurrency(rs.getString(2));
				emp.setToCurrency(rs.getString(3));
				emp.setRate(rs.getDouble(5));
				emp.setLastUpdateTimeStamp(rs.getString(6));
				emp.setSource(rs.getString(7));
				emp.setRequestedDateTime(rs.getString(8));
				employess.add(emp);
			}

			builder1.append("\n\nRecords Inserted:\n");
			System.out.println("Records Inserted");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			builder1.append(e.getMessage());
			System.out.println(e.getMessage());

		}
		return employess;
	}

}
