package com.company.fxrateaggregatorservice.JAVA;

public class ApiDetailsEntity {
	
	private String apiName;
	
	private String apiUrl;

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}
	
	

}
