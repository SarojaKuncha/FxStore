sap.ui.define([
	"UI/UI/test/unit/controller/Home.controller"
], function () {
	"use strict";
});